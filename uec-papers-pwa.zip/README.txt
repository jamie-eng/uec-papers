# UEC Papers PWA

Upload these files to the same GitHub Pages folder as the existing site:

- manifest.json
- sw.js
- download.html
- icons/icon-192.png
- icons/icon-512.png

Then open:
https://jamie-eng.github.io/uec-papers/download.html

Important:
1. The existing index.html should also include:
<link rel="manifest" href="/uec-papers/manifest.json">
<meta name="theme-color" content="#2563eb">

2. Before </body>, add:
<script>
if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("/uec-papers/sw.js");
}
</script>

3. GitHub Pages must serve the files over HTTPS (it already does).

4. The Firebase/database permissions remain controlled by the existing website/backend.
